import 'package:flutter/material.dart';
import 'package:multi_sports/screens/lederboard/leader_board.dart';
import 'package:multi_sports/screens/profile.dart';
import 'screens/event_detail_screen.dart';
import 'screens/about.dart';
import 'screens/event.dart';
import 'screens/score_home.dart';
import 'screens/captain_room/loging_captain.dart';

void main() {
  runApp(SportsCarnivalApp());
}

class SportsCarnivalApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: DashboardScreen(),
      routes: {
        '/eventDetail': (context) => EventDetailScreen(),
      },
    );
  }
}

class DashboardScreen extends StatelessWidget {
  final List<Map<String, dynamic>> menuItems = [
    {'title': 'About', 'icon': Icons.info},
    {'title': 'Rules', 'icon': Icons.rule},
    {'title': 'Sponsors', 'icon': Icons.monetization_on},
    {'title': 'Teams', 'icon': Icons.group},
    {'title': 'Gallery', 'icon': Icons.photo},
    {'title': 'Play Along', 'icon': Icons.sports_esports},
    {'title': 'Scan me', 'icon': Icons.qr_code_scanner},
    {'title': 'Events', 'icon': Icons.event},
    {'title': 'Highlights', 'icon': Icons.highlight},
    {'title': 'Captain & team', 'icon': Icons.group_add},
    {'title': 'Score', 'icon': Icons.score},
    {'title': 'Feedback', 'icon': Icons.feedback},
    
    
  ];

   final List<Map<String, dynamic>> carouselItems = [
    {
      'imageUrl': 'https://picsum.photos/250?image=1',
      'videoUrl': 'https://www.youtube.com/shorts/Wj4X_ZaktJ8',
      'title': 'Cricket Tournament',
      'description': 'Annual inter-department cricket competition'
    },
    {
      'imageUrl': 'https://picsum.photos/250?image=2',
      'videoUrl': 'https://www.youtube.com/shorts/Wj4X_ZaktJ8',
      'title': 'Football League',
      'description': 'Weekend football matches'
    },
    {
      'imageUrl': 'https://picsum.photos/250?image=3',
      'videoUrl': 'https://www.youtube.com/shorts/Wj4X_ZaktJ8',
      'title': 'Badminton Championship',
      'description': 'Singles and doubles matches'
    },
    {
      'imageUrl': 'https://picsum.photos/250?image=4',
      'videoUrl': 'https://www.youtube.com/shorts/Wj4X_ZaktJ8',
      'title': 'Athletics Meet',
      'description': 'Track and field events'
    },
    {
      'imageUrl': 'https://picsum.photos/250?image=5',
      'videoUrl': 'https://www.youtube.com/shorts/Wj4X_ZaktJ8',
      'title': 'Basketball Tournament',
      'description': '3-on-3 street basketball'
    },
  ];



  onMenuItemTap(BuildContext context,String title) {
    switch (title) {
      case 'About':
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => About()),
        );
        break;
      case 'Events':
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => Event()),
        );
        break;
      case 'Score':
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => Score()),
        );
        break;

      case 'Gallery':
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => EventDetailScreen1()),
        );
        break;
      case 'Captain & team':
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => EventDetailScreen1()),
        );
        break;
      case 'Play Along':
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => EventDetailScreen1()),
        );
        break;
      case 'Scan me':
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => EventDetailScreen1()),
        );
        break;
      case 'Highlights':
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => EventDetailScreen1()),
        );
        break;
      case 'Captain room':
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => LogingCaptain()),
        );
        break;
      default:
        print("$title tapped");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [

            // Grid Menu
            Expanded(
              child: SingleChildScrollView(
                padding: EdgeInsets.symmetric(horizontal: 10),
                child: Column(
                  children: [
                                // Header with Banner Image
            Container(
              height: 180,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.vertical(bottom: Radius.circular(15)),
                image: DecorationImage(
                  image: NetworkImage('https://picsum.photos/250?image=9'),
                  fit: BoxFit.cover,
                ),
              ),
              child: Stack(
                children: [
                  Positioned(
                    top: 10,
                    right: 4,
                    child: Row(
                      children: [
                        IconButton(
                          icon: Badge(
                            label: Text("3"),
                            child: Icon(Icons.notifications, color: Colors.white),
                          ),
                          onPressed: () => print("Notifications Clicked"),
                        ),
                        IconButton(
                            icon: Icon(Icons.person, color: Colors.white),
                            onPressed: () {
                              // Navigate to Profile Screen
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context) => Profile()),
                              );
                            },
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

              // Event Banner
                    Container(
                      width: double.infinity,
                      height: 40,
                      margin: EdgeInsets.symmetric(vertical: 15),
                      decoration: BoxDecoration(
                      gradient: LinearGradient(
                          colors: [Color.fromARGB(255, 178, 52, 6), Color(0xFFFC9A51)], // Adjust colors as needed
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        "Welcome to CSC sports carnival",
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
                      ),
                    ),
            
                    SizedBox(height: 5),
                    GridView.builder(
                      shrinkWrap: true,
                      physics: NeverScrollableScrollPhysics(),
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 3,
                        childAspectRatio: 1.2,
                        mainAxisSpacing: 5,
                        crossAxisSpacing: 5,
                      ),
                      itemCount: menuItems.length,
                      itemBuilder: (context, index) {
                        return Card(
                          elevation: 4,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: InkWell(
                            borderRadius: BorderRadius.circular(10),
                            onTap: () => onMenuItemTap(context,menuItems[index]['title']),//print("${menuItems[index]['title']} tapped"),
                            child: Center(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(menuItems[index]['icon'], size: 30, color: Colors.red),
                                  SizedBox(height: 8),
                                  Text(
                                    menuItems[index]['title'],
                                    textAlign: TextAlign.center,
                                    style: TextStyle(fontSize: 12),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                    
                    // Event Banner
                    Container(
                      width: double.infinity,
                      height: 80,
                      margin: EdgeInsets.symmetric(vertical: 15),
                      decoration: BoxDecoration(
                        color: Colors.orangeAccent,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        "Ladies Cricket",
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                      ),
                    ),
                    
                    // Image Carousel
                    Container(
                      height: 200,
                      margin: EdgeInsets.only(bottom: 15),
                      child: PageView.builder(
                        controller: PageController(viewportFraction: 0.9),
                        itemCount: carouselItems.length,
                        itemBuilder: (context, index) {
                          return GestureDetector(
                            onTap: () {
                              Navigator.pushNamed(
                                context,
                                '/eventDetail',
                                arguments: carouselItems[index],
                              );
                            },
                            child: Container(
                              margin: EdgeInsets.symmetric(horizontal: 5),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(15),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black26,
                                    blurRadius: 5,
                                    offset: Offset(0, 3),
                                  ),
                                ],
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(15),
                                child: Stack(
                                  fit: StackFit.expand,
                                  children: [
                                    Image.network(
                                      carouselItems[index]['imageUrl'],
                                      fit: BoxFit.cover,
                                    ),
                                    Container(
                                      decoration: BoxDecoration(
                                        gradient: LinearGradient(
                                          begin: Alignment.bottomCenter,
                                          end: Alignment.topCenter,
                                          colors: [
                                            Colors.black.withOpacity(0.7),
                                            Colors.transparent,
                                          ],
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      bottom: 10,
                                      left: 10,
                                      right: 10,
                                      child: Text(
                                        carouselItems[index]['title'],
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 18,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: ClipRRect(
        borderRadius: BorderRadius.vertical(top: Radius.circular(25)),
        child: Container(
          height: 70, // Increased height to prevent overflow
          child: BottomNavigationBar(
            type: BottomNavigationBarType.fixed,
            backgroundColor: Color.fromARGB(255, 255, 0, 0), // Using hex color
            selectedItemColor: Colors.white,
            unselectedItemColor: Colors.white,
            showUnselectedLabels: true,
            selectedFontSize: 12,
            unselectedFontSize: 12,
            items: [
              BottomNavigationBarItem(
                icon: Icon(Icons.leaderboard),
                label: "Leaderboard",
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.schedule),
                label: "Schedule",
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.star),
                label: "Results",
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.meeting_room),
                label: "Captain room",
               
              ),
            ],
             onTap: (index) {
                if (index == 3) {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => LogingCaptain()),
                  );
                }
                if (index == 0) {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => LeaderboardPage()),
                  );
                }
                // Handle other taps if needed

              },
          ),
        ),
      ),
    );
  }
}

class EventDetailScreen1 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final Map<String, dynamic> event = ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>;

    return Scaffold(
      appBar: AppBar(
        title: Text(event['title']),
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: Image.network(
                event['imageUrl'],
                height: 250,
                fit: BoxFit.cover,
              ),
            ),
            SizedBox(height: 20),
            Text(
              event['title'],
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 10),
            Text(
              event['description'],
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Handle event registration
              },
              child: Text('Register for Event'),
            ),
          ],
        ),
      ),
    );
  }
}